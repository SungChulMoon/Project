package weatherCodination;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.*;

import InnerClass.DBmethod;

import java.util.*;

public class test extends JPanel {
	JButton btn;
	
	JLabel imageOuterLabel;
	JLabel imageTopLabel;
	JLabel imagePantsLabel;
	JLabel imageShoesLabel;
	
	
	String temp ="";
	String stylest="";
	String sizest="";
	String[] link=new String[4];
	
	codiPanel panel;
	
	public test(String id){
	
		try {
			temp = DBmethod.getNowweatherParsed().getTemp();
			stylest = DBmethod.getUserinfo(id).getSty_str();
			sizest = DBmethod.getUserinfo(id).getSty_size();
			System.out.println(temp);
			System.out.println(stylest);
			System.out.println(sizest);
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		Scanner sc= new Scanner(System.in);
		
		//input�� �ޱ�
		System.out.println(">>");
		//temp=sc.nextInt();
		//stylest=sc.next();
		//sizest=sc.next();
		
		setLayout(null);
		
		addCloth testAddCloth=new addCloth();
		
		panel=new codiPanel( Integer.parseInt(temp), stylest, sizest);
		panel.setLocation(0,0);
		panel.setSize(1000,250);
		add(panel);
		
		ImageIcon buttonIcon=new ImageIcon("src/clothes/refresh.png");
		btn=new JButton(buttonIcon);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.removeAll();
				panel.refreshCodi(Integer.parseInt(temp), stylest, sizest);
				panel.updateUI();
			}
		});
		btn.setOpaque(false);
		btn.setLocation(1010,200);
		btn.setSize(40,40);
		
		add(btn);
		
		
	}
	
	class codiPanel extends JPanel {
		codiObject codi;
		JPanel subPanel;
		matchCloth testMatchCloth;
		
		codiPanel(int temp, String stylest,String sizest){
		
			testMatchCloth=new matchCloth(temp, stylest, sizest);
						
			subPanel=new JPanel();
			subPanel.setLayout(new GridLayout(1,4));
			
			codi= new codiObject();
			
			subPanel=new JPanel();
			subPanel.setLayout(new GridLayout(1,4));
			
			link[0]=codi.codiOuter.link;
			ImageIcon outer=new ImageIcon(codi.codiOuter.image);
			imageOuterLabel=new JLabel(outer);
			imageOuterLabel.addMouseListener(new LinkMouseListener());
			
			link[1]=codi.codiTop.link;
			ImageIcon top=new ImageIcon(codi.codiTop.image);
			imageTopLabel=new JLabel(top);
			imageTopLabel.addMouseListener(new LinkMouseListener());
			
			link[2]=codi.codiPants.link;
			ImageIcon pants=new ImageIcon(codi.codiPants.image);
			imagePantsLabel=new JLabel(pants);
			imagePantsLabel.addMouseListener(new LinkMouseListener());
			
			link[3]=codi.codiShoes.link;
			ImageIcon shoes=new ImageIcon(codi.codiShoes.image);
			imageShoesLabel=new JLabel(shoes);
			imageShoesLabel.addMouseListener(new LinkMouseListener());
			
			add(subPanel);
			subPanel.add(imageOuterLabel);
			subPanel.add(imageTopLabel);
			subPanel.add(imagePantsLabel);
			subPanel.add(imageShoesLabel);
		}
		
		private void refreshCodi(int temp, String stylest,String sizest){
		
			testMatchCloth=new matchCloth(temp, stylest, sizest);
						
			subPanel=new JPanel();
			subPanel.setLayout(new GridLayout(1,4));
			
			codi= new codiObject();
			
			subPanel=new JPanel();
			subPanel.setLayout(new GridLayout(1,4));
			
			link[0]=codi.codiOuter.link;
			ImageIcon outer=new ImageIcon(codi.codiOuter.image);
			imageOuterLabel=new JLabel(outer);
			imageOuterLabel.addMouseListener(new LinkMouseListener());
			
			link[1]=codi.codiTop.link;
			ImageIcon top=new ImageIcon(codi.codiTop.image);
			imageTopLabel=new JLabel(top);
			imageTopLabel.addMouseListener(new LinkMouseListener());
			
			link[2]=codi.codiPants.link;
			ImageIcon pants=new ImageIcon(codi.codiPants.image);
			imagePantsLabel=new JLabel(pants);
			imagePantsLabel.addMouseListener(new LinkMouseListener());
			
			link[3]=codi.codiShoes.link;
			ImageIcon shoes=new ImageIcon(codi.codiShoes.image);
			imageShoesLabel=new JLabel(shoes);
			imageShoesLabel.addMouseListener(new LinkMouseListener());
			
			add(subPanel);
			subPanel.add(imageOuterLabel);
			subPanel.add(imageTopLabel);
			subPanel.add(imagePantsLabel);
			subPanel.add(imageShoesLabel);
		}
	}
	
	class LinkMouseListener extends MouseAdapter{
		public void mouseClicked(MouseEvent e) {
			JLabel la = (JLabel)e.getSource();
			URI uri;
			if(e.getClickCount()>0) {
				if(Desktop.isDesktopSupported()) {
					Desktop desktop=Desktop.getDesktop();
					try {
						if(la.equals(imageOuterLabel)) {
							uri = new URI(link[0]);
							desktop.browse(uri);
						}else if(la.equals(imageTopLabel)) {
							uri = new URI(link[1]);
							desktop.browse(uri);
						}else if(la.equals(imagePantsLabel)) {
							uri = new URI(link[2]);
							desktop.browse(uri);
						}else if(la.equals(imageShoesLabel)){
							uri = new URI(link[3]);
							desktop.browse(uri);
						} 
					}catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			}
		}
	}
	
}
