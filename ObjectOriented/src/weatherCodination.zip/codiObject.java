package weatherCodination;

import java.util.Random;

public class codiObject {
	public static int[] match = new int[4];

	Random random=new Random();
	
	outer codiOuter;
	top codiTop;
	pants codiPants;
	shoes codiShoes;
	
	codiObject() {
		System.out.println(random.nextInt(3));
		codiOuter=addCloth.clo_outer.get(matchCloth.priorityMatrix[0][random.nextInt(3)]);
		codiTop=addCloth.clo_top.get(matchCloth.priorityMatrix[1][random.nextInt(3)]);
		codiPants=addCloth.clo_pants.get(matchCloth.priorityMatrix[2][random.nextInt(3)]);
		codiShoes=addCloth.clo_shoes.get(matchCloth.priorityMatrix[3][random.nextInt(3)]);
		
	}
}
