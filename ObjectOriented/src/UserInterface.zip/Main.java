package UserInterface;

import weatherCodination.*;
//������ getnowweatherParsed�� �Ű������� ���̵� �־� ���Ͽ� ������ ���� ���������Ѵ�
//

import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;

import InnerClass.DBmethod;
import InnerClass.LineChartEx2;
import InnerClass.User;
import InnerClass.getNowWeather;
import InnerClass.nowWeather;
import InnerClass.setLocation;

/** Class Description of Main
 * 
 * @author JaeCheol Jeong
 * @version
 * @
 *
 */
public class Main extends JFrame {
	LineChartEx2 ex ;
	private JPanel contentPane;
	private JTextField tf_local;
	private JLabel la_tip0;
	private JLabel la_tip1;
	private JLabel la_tip2;	
	private JLabel la_weather1;
	private JLabel la_weather3;
	private JLabel la_weather2;
	private JLabel lb_local;
	nowWeather nowinfo ;
	User us;
	String location="";
	String weather="";
	String weather2="";
	private JPanel panel;
	private JPanel panel_1;
	private JLabel lb_now_weather;
	private JPanel panel_forecast;
	private JPanel panel_style;
	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public Main(String id) {
			
		
		try {
			us = DBmethod.getUserinfo(id);
			getNowWeather.addParsingNowWeather();
			setLocation.setlocal(us.getLocation());
			nowinfo = DBmethod.getNowweatherParsed();
			System.out.println("����µ� "+nowinfo.getTemp());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Image img = toolkit.getImage("src/Icon.png");
		setIconImage(img);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 50, 1151, 1109);
		setTitle("��������");
		setResizable(false);

		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		tf_local = new JTextField();
		tf_local.setBounds(110, 45, 905, 40);
		contentPane.add(tf_local);
		tf_local.setColumns(10);
		
		if(tf_local.getText().equals("����")) {
			location ="Gwangju";
		}
		else if(tf_local.getText().equals("����")) {
			location = "Seoul";
		}
		else if(tf_local.getText().equals("�λ�")) {
			location ="Busan";
		}
		
		ImageIcon Icon_search = new ImageIcon("src/search.PNG");
		ImageIcon Icon_refresh = new ImageIcon("src/refresh.PNG");
		JButton btn_search = new JButton(Icon_search);
		btn_search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setLocation.stopThread();
				setLocation.setlocal(location);
				
				try {
					getNowWeather.addParsingNowWeather();
					nowinfo = DBmethod.getNowweatherParsed();
					lb_local.setText("���� : "+ nowinfo.getLocation());
					la_weather1.setText("������ : "+nowinfo.getTemp());
					la_weather2.setText("���� ��� : "+nowinfo.getMaxtemp());
					la_weather3.setText("�ְ� ��� : "+nowinfo.getMintemp());
					lb_now_weather.setText("���� ���� : "+nowinfo.getMain());
				ex = new LineChartEx2();
				panel_forecast.add(ex);
				ex.setVisible(true);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
				repaint();
			}
		});
		btn_search.setBackground(Color.WHITE);
		btn_search.setBounds(1056, 45, 40, 40);
		contentPane.add(btn_search);
		
		String tip0 = "�ϱ����� Ů�ϴ�. �ѿ��� ì�⼼��";
		String tip0_link = "http://store.musinsa.com/app/product/detail/601276/0";
		la_tip0 = new JLabel(tip0);
		la_tip0.setFont(new Font("�����ٸ�����", Font.PLAIN, 20));
		la_tip0.setBackground(Color.WHITE);
		la_tip0.setBounds(65, 565, 460, 40);
		la_tip0.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		la_tip0.addMouseListener(new MouseAdapter() {
		   public void mouseClicked(MouseEvent e) {
		      if (e.getClickCount() > 0) {
		          if (Desktop.isDesktopSupported()) {
		                Desktop desktop = Desktop.getDesktop();
		                try {
		                    URI uri = new URI(tip0_link);
		                    desktop.browse(uri);
		                } catch (IOException ex) {
		                    ex.printStackTrace();
		                } catch (URISyntaxException ex) {
		                    ex.printStackTrace();
		                }
		        }
		      }
		   }
		});
		contentPane.add(la_tip0);
	
		String tip1 = "��ǳ ���� ���� �����Դϴ�!! ���ڸ��� ì�⼼��";
		String tip1_link = "http://storefarm.naver.com/mimidari/products/659638670?NaPm=ct%3Dja14njcw%7Cci%3Dfca87b58a32d5807ab5dab601eb1fcd2ba139745%7Ctr%3Dslsl%7Csn%3D354611%7Cic%3D%7Chk%3Def8b50cac278a181c51e2ad775eddd013cab74bb";
		la_tip1 = new JLabel(tip1);
		la_tip1.setFont(new Font("�����ٸ�����", Font.PLAIN, 20));
		la_tip1.setBackground(Color.WHITE);
		la_tip1.setBounds(65, 639, 460, 40);
		la_tip1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		la_tip1.addMouseListener(new MouseAdapter() {
		   public void mouseClicked(MouseEvent e) {
		      if (e.getClickCount() > 0) {
		          if (Desktop.isDesktopSupported()) {
		                Desktop desktop = Desktop.getDesktop();
		                try {
		                    URI uri = new URI(tip1_link);
		                    desktop.browse(uri);
		                } catch (IOException ex) {
		                    ex.printStackTrace();
		                } catch (URISyntaxException ex) {
		                    ex.printStackTrace();
		                }
		        }
		      }
		   }
		});
		contentPane.add(la_tip1);
		
		String tip2 = "tip2";
		String tip2_link = "http://naver.com";
		la_tip2 = new JLabel(tip2);
		la_tip2.setFont(new Font("�����ٸ�����", Font.PLAIN, 20));
		la_tip2.setBackground(Color.WHITE);
		la_tip2.setBounds(110, 695, 460, 40);
		la_tip2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		la_tip2.addMouseListener(new MouseAdapter() {
		   public void mouseClicked(MouseEvent e) {
		      if (e.getClickCount() > 0) {
		          if (Desktop.isDesktopSupported()) {
		                Desktop desktop = Desktop.getDesktop();
		                try {
		                    URI uri = new URI(tip2_link);
		                    desktop.browse(uri);
		                } catch (IOException ex) {
		                    ex.printStackTrace();
		                } catch (URISyntaxException ex) {
		                    ex.printStackTrace();
		                }
		        }
		      }
		   }
		});
		contentPane.add(la_tip2);
		
		ImageIcon outer = new ImageIcon("src/outer.PNG");
		ImageIcon top = new ImageIcon("src/top.PNG");
		ImageIcon pants = new ImageIcon("src/pants.png");
		ImageIcon shoes = new ImageIcon("src/shoes.png");
		
		String lb0_link ="http://store.musinsa.com/app/product/detail/601276/0";
		
		String lb1_link = "http://store.musinsa.com/app/product/detail/459980/0";
		
		String lb2_link = "http://store.musinsa.com/app/product/detail/466299/0";
		
		String lb3_link = "http://store.musinsa.com/app/product/detail/104238/0";
		
		System.out.println(nowinfo.getMain());
		switch (nowinfo.getMain()) {
		case "Clear":
			weather ="src/sun1.png";
			weather2 ="src/sun2.png";
			break;
		case "Rain":
		case "Drizzle":
			weather ="src/rain1.png";
			weather2 ="src/rain2.png";
			break;
		case "Mist":
		case "Haze":
		case "Fog":
			weather = "src/fog1.png";
			weather2 = "src/fog2.png";
			break;
		case "Clouds":
			weather = "src/cloudy1.png";
			weather2 ="src/cloudy2.png";
			break;
		case "Lightning":
		case "Thunderstorm":
			weather = "src/thunder1.png";
			weather2 = "src/thunder2.png";
			break;
		case "Snow":
			weather ="src/snow1.png";
			weather2 ="src/snow2.png";
			break;
		default:
			weather ="src/sun1.png";
			weather ="src/sun2.png";
			break;
		}
		ImageIcon weatherIcon = new ImageIcon(weather);
		
		ImageIcon weatherIcon2 = new ImageIcon(weather2);
		la_weather1 = new JLabel("���� ��� : "+nowinfo.getTemp());
		la_weather1.setFont(new Font("����", Font.PLAIN, 23));
		la_weather1.setBounds(40, 128, 150, 65);
		contentPane.add(la_weather1);
		
		la_weather2 = new JLabel("���� ��� : "+nowinfo.getMintemp());
		la_weather2.setFont(new Font("����", Font.PLAIN, 23));
		la_weather2.setBounds(193, 128, 150, 65);
		contentPane.add(la_weather2);
		
		la_weather3 = new JLabel("�ְ� ��� : "+nowinfo.getMaxtemp());
		la_weather3.setFont(new Font("����", Font.PLAIN, 23));
		la_weather3.setBounds(344, 128, 150, 65);
		contentPane.add(la_weather3);
		
		lb_local = new JLabel("���� : "+nowinfo.getLocation());
		lb_local.setFont(new Font("����", Font.PLAIN, 25));
		lb_local.setBounds(110, 97, 228, 28);
		contentPane.add(lb_local);
		
		panel = new JPanel() {
			public void paintComponent(Graphics g) {
				g.drawImage(weatherIcon.getImage(),0,0, this.getWidth(),this.getHeight(),null);
			}
		};
		
		panel.setBounds(40, 250, 200, 200);
		contentPane.add(panel);
		
		panel_1 = new JPanel() {
			public void paintComponent(Graphics g) {
			g.drawImage(weatherIcon2.getImage(),0,0, this.getWidth(),this.getHeight(),null);
		}};
		panel_1.setBounds(286, 250, 200, 200);
		contentPane.add(panel_1);
		
		lb_now_weather = new JLabel("���� ���� : "+nowinfo.getMain());
		lb_now_weather.setFont(new Font("����", Font.PLAIN, 25));
		lb_now_weather.setBounds(40, 200, 228, 21);
		contentPane.add(lb_now_weather);
		
		panel_forecast = new JPanel();
		panel_forecast.setBounds(495, 126, 633, 442);
		contentPane.add(panel_forecast);
		 ex = new LineChartEx2();
		panel_forecast.add(ex);
		panel_forecast.setOpaque(false);
		
		
		test ts = new test(id);
		ts.setBounds(17, 723, 1090, 279);
		ts.setOpaque(false);
		contentPane.add(ts);
	
	
		
	}

	class Panel_main extends JPanel{
		ImageIcon icon = new ImageIcon("src/���");
		Image img = icon.getImage();

		public void paintComponent(Graphics g){
			super.paintComponent(g);
			g.drawImage(img, 0 , 0 , this.getWidth(), this.getHeight(), this);
    	}
	}
	
	
}